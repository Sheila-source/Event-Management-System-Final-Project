-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2021 at 12:18 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventlist`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) NOT NULL,
  `event_column` varchar(50) NOT NULL,
  `schedule` date NOT NULL,
  `venue` varchar(50) NOT NULL,
  `in_charge` varchar(50) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_column`, `schedule`, `venue`, `in_charge`, `created_at`, `updated_at`) VALUES
(6, 'Holy Mass', '2021-03-21', 'Gymnasium', 'Hector Damaso', '2021-03-19 02:50:57.000000', '2021-03-19 02:50:57.000000'),
(7, 'Acquaintance Party', '2021-03-19', 'Gymnasium', 'Aldrin Daiz', '2021-03-19 02:51:15.000000', '2021-03-19 02:51:15.000000'),
(8, 'Paskuhan', '2021-03-20', 'Gymnasium', 'Mario Castillo', '2021-03-19 02:51:37.000000', '2021-03-19 02:51:37.000000'),
(9, 'Midterm Exam', '2021-03-19', 'IT 304 Room', 'Ryan Galendez', '2021-03-19 02:51:52.000000', '2021-03-19 02:51:52.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
